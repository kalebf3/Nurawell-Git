import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertConversationSchema, insertMessageSchema, insertMoodEntrySchema } from "@shared/schema";
import { z } from "zod";

const chatRequestSchema = z.object({
  message: z.string().min(1).max(2000),
  conversationId: z.string().uuid().optional(),
});

const moodSchema = z.object({
  mood: z.number().min(1).max(5),
  notes: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Conversation routes
  app.get('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.get('/api/conversations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const conversation = await storage.getConversation(id, userId);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      const messages = await storage.getMessages(id);
      res.json({ conversation, messages });
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.post('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertConversationSchema.parse({
        ...req.body,
        userId,
      });
      
      const conversation = await storage.createConversation(validatedData);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  // Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message, conversationId } = chatRequestSchema.parse(req.body);
      
      let currentConversationId = conversationId;
      
      // Create conversation if it doesn't exist
      if (!currentConversationId) {
        const conversation = await storage.createConversation({
          userId,
          title: message.substring(0, 50) + (message.length > 50 ? '...' : ''),
        });
        currentConversationId = conversation.id;
      }

      // Store user message
      await storage.createMessage({
        conversationId: currentConversationId,
        content: message,
        role: 'user',
      });

      // Call AI service
      try {
        const aiResponse = await fetch('http://localhost:8000/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message,
            max_new_tokens: 300,
            temperature: 0.7,
          }),
        });

        if (!aiResponse.ok) {
          throw new Error(`AI service error: ${aiResponse.status}`);
        }

        const aiData = await aiResponse.json();
        const assistantMessage = aiData.response || "I apologize, but I'm having trouble processing your request right now. Please try again.";

        // Store AI response
        await storage.createMessage({
          conversationId: currentConversationId,
          content: assistantMessage,
          role: 'assistant',
        });

        res.json({
          message: assistantMessage,
          conversationId: currentConversationId,
        });

      } catch (aiError) {
        console.error("AI service error:", aiError);
        
        // Store fallback message
        const fallbackMessage = "I'm sorry, but I'm experiencing technical difficulties right now. Please try again in a moment, or if this is an emergency, please contact emergency services at 988 or 911.";
        
        await storage.createMessage({
          conversationId: currentConversationId,
          content: fallbackMessage,
          role: 'assistant',
        });

        res.json({
          message: fallbackMessage,
          conversationId: currentConversationId,
        });
      }

    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // Mood tracking routes
  app.post('/api/mood', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = moodSchema.parse(req.body);
      
      const moodEntry = await storage.createMoodEntry({
        userId,
        ...validatedData,
      });
      
      res.json(moodEntry);
    } catch (error) {
      console.error("Error creating mood entry:", error);
      res.status(500).json({ message: "Failed to record mood" });
    }
  });

  app.get('/api/mood', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moodEntries = await storage.getRecentMoodEntries(userId);
      res.json(moodEntries);
    } catch (error) {
      console.error("Error fetching mood entries:", error);
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
