import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  dark?: boolean;
}

export default function GlassCard({ children, className, dark = false }: GlassCardProps) {
  return (
    <div 
      className={cn(
        "rounded-3xl shadow-2xl",
        dark ? "glass-dark" : "glass",
        className
      )}
    >
      {children}
    </div>
  );
}
