import { Bot } from "lucide-react";

export default function TypingIndicator() {
  return (
    <div className="animate-fade-in" data-testid="typing-indicator">
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="text-white w-4 h-4" />
        </div>
        <div className="chat-bubble-ai rounded-2xl rounded-tl-sm p-4 shadow-lg">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
            </div>
            <span className="text-gray-500 text-sm">NuraWell is thinking...</span>
          </div>
        </div>
      </div>
    </div>
  );
}
