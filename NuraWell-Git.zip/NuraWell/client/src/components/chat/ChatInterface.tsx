import { useState, useRef, useEffect } from "react";
import { Send, Bot, AlertTriangle } from "lucide-react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import MessageBubble from "./MessageBubble";
import TypingIndicator from "./TypingIndicator";
import type { Message } from "@shared/schema";

interface ConversationData {
  conversation: any;
  messages: Message[];
}

export default function ChatInterface() {
  const { conversationId } = useParams();
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: conversationData, isLoading } = useQuery<ConversationData>({
    queryKey: ["/api/conversations", conversationId],
    enabled: !!conversationId,
    retry: false,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest("POST", "/api/chat", {
        message: messageText,
        conversationId,
      });
      return response.json();
    },
    onSuccess: () => {
      if (conversationId) {
        queryClient.invalidateQueries({ queryKey: ["/api/conversations", conversationId] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setIsTyping(false);
    },
    onError: (error) => {
      setIsTyping(false);
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedMessage = message.trim();
    if (!trimmedMessage) return;

    setMessage("");
    setIsTyping(true);
    sendMessageMutation.mutate(trimmedMessage);

    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleQuickAction = (actionText: string) => {
    setMessage(actionText);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversationData?.messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + "px";
    }
  }, [message]);

  const quickActions = [
    "I'm feeling anxious and would like some help managing it.",
    "I'm having trouble sleeping and need some guidance.",
    "I'm dealing with work stress and need coping strategies.",
    "I'd like to track my mood and understand my patterns better.",
  ];

  return (
    <div className="flex-1 flex flex-col">
      {/* Chat Header */}
      <div className="glass p-6 border-b border-white/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 gradient-bg rounded-full flex items-center justify-center">
              <Bot className="text-white w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">NuraWell AI</h2>
              <p className="text-sm text-gray-600">Your personal mental health assistant</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-600">Online</span>
          </div>
        </div>
        
        {/* Safety Disclaimer */}
        <div className="mt-4 p-3 bg-pastel-yellow rounded-lg border border-yellow-300">
          <p className="text-sm text-gray-700">
            <AlertTriangle className="inline w-4 h-4 text-yellow-600 mr-2" />
            For mental health emergencies, please contact emergency services or call the crisis hotline: 988
          </p>
        </div>
      </div>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 scroll-smooth">
        {!conversationId && (
          <div className="animate-slide-up">
            <MessageBubble
              message={{
                id: "welcome",
                content: "Hello! I'm NuraWell, your AI mental health companion. I'm here to listen, provide support, and suggest holistic practices for your wellbeing. What would you like to talk about today?",
                role: "assistant",
                conversationId: "",
                timestamp: new Date(),
              }}
            />
          </div>
        )}
        
        {isLoading && conversationId && (
          <div className="flex justify-center py-8">
            <div className="glass rounded-xl p-4">
              <div className="animate-pulse text-gray-600">Loading conversation...</div>
            </div>
          </div>
        )}
        
        {conversationData?.messages.map((msg) => (
          <div key={msg.id} className="animate-slide-up">
            <MessageBubble message={msg} />
          </div>
        ))}
        
        {isTyping && <TypingIndicator />}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message Input */}
      <div className="glass p-6 border-t border-white/20">
        <form onSubmit={handleSubmit} className="flex items-end space-x-3" data-testid="form-send-message">
          <div className="flex-1">
            <Textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Share what's on your mind... NuraWell is here to help."
              className="min-h-[48px] max-h-[120px] resize-none border-2 border-gray-200 focus:border-purple-red rounded-xl"
              data-testid="input-message"
            />
          </div>
          
          <Button
            type="submit"
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="gradient-bg text-white hover-scale shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="button-send"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
        
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 mt-4">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={() => handleQuickAction(action)}
              className="px-3 py-1 text-xs bg-purple-100 text-purple-red rounded-full hover:bg-purple-200 transition-colors"
              data-testid={`quick-action-${index}`}
            >
              {index === 0 && "I'm feeling anxious"}
              {index === 1 && "Sleep problems"}
              {index === 2 && "Work stress"}
              {index === 3 && "Mood tracking"}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
