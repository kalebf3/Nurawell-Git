import { User } from "lucide-react";
import { Bot } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import type { Message } from "@shared/schema";

interface MessageBubbleProps {
  message: Message;
}

export default function MessageBubble({ message }: MessageBubbleProps) {
  const { user } = useAuth();
  const isUser = message.role === "user";

  const getUserInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
    }
    if (user.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return "U";
  };

  if (isUser) {
    return (
      <div className="flex items-start space-x-3 justify-end">
        <div className="chat-bubble-user rounded-2xl rounded-tr-sm p-4 max-w-md shadow-lg">
          <p className="text-white" data-testid={`message-user-${message.id}`}>
            {message.content}
          </p>
        </div>
        <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
          <span className="text-gray-600 text-sm font-semibold">
            {getUserInitials()}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-3">
      <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center flex-shrink-0">
        <Bot className="text-white w-4 h-4" />
      </div>
      <div className="chat-bubble-ai rounded-2xl rounded-tl-sm p-4 max-w-md shadow-lg">
        <div className="text-gray-800" data-testid={`message-ai-${message.id}`}>
          {message.content.split('\n').map((line, index) => (
            <p key={index} className={index > 0 ? "mt-2" : ""}>
              {line}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}
