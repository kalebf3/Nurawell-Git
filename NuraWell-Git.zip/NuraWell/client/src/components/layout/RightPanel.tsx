import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";
import { Phone, Ambulance, TrendingUp } from "lucide-react";
import type { MoodEntry } from "@shared/schema";

export default function RightPanel() {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moodEntries } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood"],
    retry: false,
  });

  const { data: conversations } = useQuery({
    queryKey: ["/api/conversations"],
    retry: false,
  });

  const moodMutation = useMutation({
    mutationFn: async (mood: number) => {
      const response = await apiRequest("POST", "/api/mood", { mood });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood"] });
      toast({
        title: "Mood recorded",
        description: "Thank you for checking in with yourself today.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to record mood",
        variant: "destructive",
      });
    },
  });

  const handleMoodSelect = (mood: number) => {
    setSelectedMood(mood);
    moodMutation.mutate(mood);
  };

  const getMoodEmoji = (mood: number) => {
    const emojis = ["😞", "😐", "🙂", "😊", "😄"];
    return emojis[mood - 1];
  };

  const practices = [
    {
      title: "5-Minute Breathing",
      description: "Guided breathing exercise",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&w=300&h=120&fit=crop",
    },
    {
      title: "Gentle Yoga",
      description: "Stress relief routine",
      image: "https://images.unsplash.com/photo-1545389336-cf090694435e?ixlib=rb-4.0.3&w=300&h=120&fit=crop",
    },
    {
      title: "Mindful Journaling",
      description: "Daily reflection practice",
      image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&w=300&h=120&fit=crop",
    },
  ];

  const todaysMood = moodEntries?.[0];
  const conversationCount = Array.isArray(conversations) ? conversations.length : 0;
  const activeDays = moodEntries ? new Set(moodEntries.map(entry => 
    new Date(entry.createdAt!).toDateString()
  )).size : 0;

  return (
    <div className="w-80 glass p-6 border-l border-white/20">
      {/* Today's Mood */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Today's Check-in</h3>
        <div className="glass-dark rounded-xl p-4">
          <p className="text-white text-sm mb-3">How are you feeling today?</p>
          <div className="flex justify-between items-center">
            {[1, 2, 3, 4, 5].map((mood) => (
              <button
                key={mood}
                onClick={() => handleMoodSelect(mood)}
                disabled={moodMutation.isPending}
                className={`text-2xl hover:scale-110 transition-transform ${
                  selectedMood === mood || todaysMood?.mood === mood ? "scale-110" : ""
                }`}
                data-testid={`mood-${mood}`}
              >
                {getMoodEmoji(mood)}
              </button>
            ))}
          </div>
          {todaysMood && (
            <p className="text-gray-300 text-xs mt-2 text-center">
              Today: {getMoodEmoji(todaysMood.mood)}
            </p>
          )}
        </div>
      </div>
      
      {/* Recommended Practices */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recommended for You</h3>
        <div className="space-y-3">
          {practices.map((practice, index) => (
            <div
              key={index}
              className="glass rounded-xl p-4 hover:bg-white/20 cursor-pointer transition-colors"
              data-testid={`practice-${index}`}
            >
              <img
                src={practice.image}
                alt={practice.title}
                className="w-full h-20 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-gray-800 text-sm">{practice.title}</h4>
              <p className="text-gray-600 text-xs">{practice.description}</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Quick Stats */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Your Progress</h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-gray-600 text-sm">Conversations</span>
            <span className="font-semibold text-purple-red" data-testid="stat-conversations">
              {conversationCount}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600 text-sm">Days active</span>
            <span className="font-semibold text-purple-red" data-testid="stat-active-days">
              {activeDays}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600 text-sm">Mood entries</span>
            <span className="font-semibold text-purple-red" data-testid="stat-mood-entries">
              {moodEntries?.length || 0}
            </span>
          </div>
        </div>
      </div>
      
      {/* Emergency Resources */}
      <div className="bg-red-50 border border-red-200 rounded-xl p-4">
        <h4 className="font-semibold text-red-700 mb-2">Need Immediate Help?</h4>
        <div className="space-y-2 text-sm">
          <a
            href="tel:988"
            className="flex items-center text-red-600 hover:text-red-700"
            data-testid="link-crisis-line"
          >
            <Phone className="w-4 h-4 mr-2" />
            Crisis Lifeline: 988
          </a>
          <a
            href="tel:911"
            className="flex items-center text-red-600 hover:text-red-700"
            data-testid="link-emergency"
          >
            <Ambulance className="w-4 h-4 mr-2" />
            Emergency: 911
          </a>
        </div>
      </div>
    </div>
  );
}
