import { Plus, Settings, HelpCircle, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import type { Conversation } from "@shared/schema";

export default function Sidebar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: conversations, isLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
    retry: false,
  });

  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversations", {
        title: "New Conversation",
      });
      return response.json();
    },
    onSuccess: (conversation) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setLocation(`/chat/${conversation.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create new conversation",
        variant: "destructive",
      });
    },
  });

  const handleNewChat = () => {
    createConversationMutation.mutate();
  };

  const getUserInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
    }
    if (user.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return "U";
  };

  const getUserDisplayName = () => {
    if (!user) return "User";
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user.firstName) {
      return user.firstName;
    }
    if (user.email) {
      return user.email.split("@")[0];
    }
    return "User";
  };

  return (
    <div className="w-80 glass-dark p-6 flex flex-col">
      {/* User Profile Section */}
      <div className="flex items-center space-x-3 mb-8">
        <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
          <span className="text-white font-semibold text-sm" data-testid="text-user-initials">
            {getUserInitials()}
          </span>
        </div>
        <div>
          <h3 className="text-white font-semibold" data-testid="text-user-name">
            {getUserDisplayName()}
          </h3>
          <p className="text-gray-300 text-sm">Mental Health Journey</p>
        </div>
      </div>
      
      {/* New Chat Button */}
      <Button
        onClick={handleNewChat}
        disabled={createConversationMutation.isPending}
        className="w-full gradient-bg text-white hover-scale shadow-lg mb-6"
        data-testid="button-new-chat"
      >
        <Plus className="w-4 h-4 mr-2" />
        {createConversationMutation.isPending ? "Creating..." : "New Conversation"}
      </Button>
      
      {/* Conversation History */}
      <div className="flex-1 overflow-y-auto">
        <h4 className="text-gray-300 font-medium mb-4">Recent Conversations</h4>
        
        <div className="space-y-2">
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="glass rounded-xl p-3 animate-pulse">
                  <div className="h-4 bg-white/20 rounded mb-2"></div>
                  <div className="h-3 bg-white/10 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : conversations?.length ? (
            conversations.map((conversation) => (
              <div
                key={conversation.id}
                onClick={() => setLocation(`/chat/${conversation.id}`)}
                className="glass rounded-xl p-3 hover:bg-white/20 cursor-pointer transition-colors"
                data-testid={`conversation-${conversation.id}`}
              >
                <h5 className="text-white text-sm font-medium truncate">
                  {conversation.title}
                </h5>
                <p className="text-gray-300 text-xs mt-1">
                  {new Date(conversation.createdAt!).toLocaleDateString()}
                </p>
              </div>
            ))
          ) : (
            <div className="text-gray-400 text-sm text-center py-4">
              No conversations yet. Start your first chat!
            </div>
          )}
        </div>
      </div>
      
      {/* Bottom Navigation */}
      <div className="pt-6 border-t border-white/20">
        <nav className="space-y-2">
          <button className="flex items-center space-x-3 text-gray-300 hover:text-white py-2 px-3 rounded-lg hover:bg-white/10 transition-colors w-full text-left">
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </button>
          <button className="flex items-center space-x-3 text-gray-300 hover:text-white py-2 px-3 rounded-lg hover:bg-white/10 transition-colors w-full text-left">
            <HelpCircle className="w-4 h-4" />
            <span>Help & Support</span>
          </button>
          <button
            onClick={() => window.location.href = '/api/logout'}
            className="flex items-center space-x-3 text-gray-300 hover:text-white py-2 px-3 rounded-lg hover:bg-white/10 transition-colors w-full text-left"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </nav>
      </div>
    </div>
  );
}
