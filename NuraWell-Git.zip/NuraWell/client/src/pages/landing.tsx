import { Brain, Heart, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import GlassCard from "@/components/ui/glass-card";

export default function Landing() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-purple-50 to-pink-50">
      <GlassCard className="max-w-md w-full p-8 animate-fade-in">
        <div className="text-center mb-8">
          <div className="w-20 h-20 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Brain className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold gradient-text mb-2">NuraWell</h1>
          <p className="text-gray-600">Your AI Mental Health Companion</p>
        </div>
        
        <div className="space-y-6 mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-pastel-yellow rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-purple-red" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800">Compassionate Support</h3>
              <p className="text-sm text-gray-600">AI-powered mental health guidance</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-pastel-yellow rounded-full flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-purple-red" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800">Holistic Practices</h3>
              <p className="text-sm text-gray-600">Personalized wellness recommendations</p>
            </div>
          </div>
        </div>
        
        <Button 
          onClick={() => window.location.href = '/api/login'}
          className="w-full gradient-bg text-white hover-scale shadow-lg"
          data-testid="button-login"
        >
          Get Started
        </Button>
        
        <div className="mt-6 p-3 bg-pastel-yellow rounded-lg border border-yellow-300">
          <p className="text-sm text-gray-700 text-center">
            <strong>Crisis Support:</strong> If you're in crisis, call 988 or 911 immediately
          </p>
        </div>
      </GlassCard>
    </div>
  );
}
